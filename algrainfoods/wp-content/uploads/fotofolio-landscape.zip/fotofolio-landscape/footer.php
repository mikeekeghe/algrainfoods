<div class="footer">
			Copyright <?php the_date('Y'); ?> <?php bloginfo('title'); ?> <br />
			All Rights Reserved
		</div> <!-- end of footer -->

	</div></div> <!-- end of container -->
	<?php wp_footer(); ?>
	</body>
</html>
