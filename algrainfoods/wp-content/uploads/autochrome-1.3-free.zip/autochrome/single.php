<?php get_header(); ?>
<?php get_template_part( 'photo', 'index' ); ?>
<?php get_footer(); ?>