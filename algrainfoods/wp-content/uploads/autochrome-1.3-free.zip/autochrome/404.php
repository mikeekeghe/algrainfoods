<?php get_header(); ?>

<div class="_photo _nophoto">
	<div class="not-found">
		<p class="title">(404) Not Found</p>
		<p class="tagline"><?php _e('No! I\'ve no clue about the Photo!'); ?></p>
	</div>
</div>

<?php get_footer(); ?>