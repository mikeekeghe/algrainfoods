<section id="search">
	<form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
	    <input type="search" id="s" name="s" value="" placeholder="Search" />
	    <button id="searchsubmit" type="submit" class="s16r icon-search">Search</button>
	</form>
</section>