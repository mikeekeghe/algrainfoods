<script src="//ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php bloginfo('template_url') ?>/js/jquery-1.6.2.min.js">\x3C/script>')</script>
<script src="<?php bloginfo('template_url'); ?>/js/autochrome.min.js"></script>

<?php wp_footer(); ?>
</body>
</html>