Autochrome
http://autochrome.brajeshwar.com/
----------------------------------------------

PRO (Version 2 and above)

Autochrome v1.2 is the last FREE version.
Get the PRO version for more features, such as

* Multiple Galleries.
* Portrait Photo support.
* Bug Fixes.

----------------------------------------------

INSTALL

* Just drop the "autochrome" theme folder inside "wp-contents/themes/".

----------------------------------------------

THE RIGHT WAY TO POST/UPLOAD PHOTOS

1. In your "New Post", upload/insert your desired Photo.
2. Once uploaded, choose your desired "Size". I'd suggest the best one, so choose the "Full Size".
3. Choose "Use as featured image".
4. "Save all change" and you can close that box (Modal Window).
5. Publish.

----------------------------------------------

Latest and most updated version of this README and other details at
http://autochrome.brajeshwar.com/readme/

----------------------------------------------

CHANGELOG

v1.3
	* HTML5 in lieu of Modernizr.
	* Google Webfont "Abel" insted of Miso.

v1.2
	* Custom Menu support added.
	* Added "h" as another shortcut to Home.
	* Introduce a default "Favicon". Future: Custom favicon.
	* Edit option for logged in Admin or user with appropriate access right.
	* Changed "Next" & "Prev" to a more human terms of "Older" & "Newer" respectively.
	* Search won't leave a gap when removed from the code. Want to remove Search? Go to "header.php" and remove "<?php get_search_form(); ?>".

v1.1 (09 Aug, 2011)
	* Added Changelog.
	* Linked to the correct minified version of jQuery on Google Ajax API Directory.
	* Removed the Placeholder JS. It was rather useless. Modern browsers will display it will it will degrade gracefully in older browsers.
	* Removed "modal.php" test file.
	
----------------------------------------------