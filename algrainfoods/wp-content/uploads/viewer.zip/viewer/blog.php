<?php
/*
  Template Name: Blog Page
 */
?>
<?php get_header(); ?>
	<div class="clear"></div>
        <div class="page-content">
		<h1 class="single-heading">Blog Page</h1>
          <div class="grid_16 alpha">
            <div class="content-bar">
           	<?php
            $limit = get_option('posts_per_page');
            $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
            query_posts('showposts=' . $limit . '&paged=' . $paged);
            $wp_query->is_archive = true;
            $wp_query->is_home = false;
            ?>
			<!-- Start the Loop. -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<!--post Start-->
              <div class="post">
                <h1 class="post_title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
                 <ul class="post_meta">
                    <li class="post_date"><?php echo get_the_time('m, d, Y') ?></li>
                    <li class="post_category"><span>/&nbsp;&nbsp;Category</span>&nbsp;<?php the_category(', '); ?></li>
                    <li class="posted_by"><span>/&nbsp;&nbsp;</span>Posted By&nbsp;<?php the_author_posts_link(); ?></li>
                    <li class="postc_comment"><span>/&nbsp;&nbsp;</span>&nbsp;<?php comments_popup_link('No Comments.', '1 Comment.', '% Comments.'); ?></li>
                  </ul>
                <div class="post_content"> <?php if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())) { ?>
                         <?php inkthemes_get_thumbnail(250, 170); ?>
                    <?php } else { ?>
                        <?php inkthemes_get_image(250, 170); ?> 
                        <?php
                    }
                    ?>	
                  <?php the_excerpt(); ?>
				  <div class="clear"></div>
                    <?php if (has_tag()) { ?>
                        <div class="tag">
                            <?php the_tags('Post Tagged with ', ', ', ''); ?>
                        </div>
                    <?php } ?>                 
                  <a class="read_more" href="<?php the_permalink() ?>">Read More</a> </div>
              </div>
              <!--post End-->
			  <?php endwhile;
else: ?>
   <div class="post">
        <p>
            <?php _e('Sorry, no posts matched your criteria.', 'andrina'); ?>
        </p>
    </div>
<?php endif; ?>
<!--End Loop-->
<div class="clear"></div>
			<nav id="nav-single"> <span class="nav-previous">
                    <?php next_posts_link(__('&larr; Older posts', 'andrina')); ?>
                </span> <span class="nav-next">
                    <?php previous_posts_link(__('Newer posts &rarr;', 'andrina')); ?>
                </span> </nav>
          </div>
		  </div>
          <div class="grid_8 omega">
 <!--Start Sidebar-->
        <?php get_sidebar(); ?>
        <!--End Sidebar-->
          </div>
        </div>
      </div>
	  <?php get_footer(); ?>