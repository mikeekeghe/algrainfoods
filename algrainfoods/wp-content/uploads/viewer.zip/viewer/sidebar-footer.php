<div class="grid_6 alpha">
    <div class="widget_inner">
        <?php if (is_active_sidebar('first-footer-widget-area')) : ?>
            <?php dynamic_sidebar('first-footer-widget-area'); ?>
        <?php else : ?>
            <h4>Setting Footer Widgets</h4>
			Footer is widgetized. To setup the footer, drag the required Widgets in Appearance -> Widgets Tab in the First, Second or Third Footer Widget Areas.
        <?php endif; ?>
    </div>
</div>
<div class="grid_7">
    <div class="widget_inner">
        <?php if (is_active_sidebar('second-footer-widget-area')) : ?>
            <?php dynamic_sidebar('second-footer-widget-area'); ?>
        <?php else : ?> 
            <h4>Buyers & Other Links</h4>
            <p> Qarius dui, quis posuere nibh ollis quis. Mauris omma rhoncus rttitor.  </p>
            <form class="searchform" action="#" method="get">
                <input onfocus="if (this.value == 'Search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search';}"  value="Search" type="text" value="" name="s" id="s" />
                <input type="submit" value="" name="submit"/>
            </form>
        <?php endif; ?>
    </div>
</div>
<div class="grid_11 omega">
    <div class="widget_inner last">
        <?php if (is_active_sidebar('third-footer-widget-area')) : ?>
            <?php dynamic_sidebar('third-footer-widget-area'); ?>
        <?php else : ?>
            <h4>Recent From Blog</h4>
            <p> Qarius dui, quis posuere nibh ollis quis. Mauris omma rhoncus rttitor.Email-id:&nbsp;<a href="#">pankaj@neepantech.com</a> </p>

            <p> Qarius dui, quis posuere nibh ollis quis. Mauris omma rhoncus rttitor. <a href="#">http://inkthemes.com</a></p>
        <?php endif; ?>
    </div>
</div>
<div class="clear"></div>