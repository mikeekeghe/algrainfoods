<?php

add_action('init', 'of_options');
if (!function_exists('of_options')) {

    function of_options() {
        // VARIABLES
        $themename = get_theme_data(TEMPLATEPATH . '/style.css');
        $themename = $themename['Name'];
        $shortname = "of";
        // Populate OptionsFramework option in array for use in theme
        global $of_options;
        $of_options = inkthemes_get_option('of_options');
        //Front page on/off
        $file_rename = array("on" => "On", "off" => "Off");
        // Background Defaults
        $background_defaults = array('color' => '', 'image' => '', 'repeat' => 'repeat', 'position' => 'top center', 'attachment' => 'scroll');
        //Stylesheet Reader
        $alt_stylesheets = array("green" => "green" , "black" => "black", "blue" => "blue", "grass" => "grass", "orange" => "orange", "purple" => "purple", "red" => "red", "yellow" => "yellow");
        // Pull all the categories into an array
        $options_categories = array();
        $options_categories_obj = get_categories();
        foreach ($options_categories_obj as $category) {
            $options_categories[$category->cat_ID] = $category->cat_name;
        }

        // Pull all the pages into an array
        $options_pages = array();
        $options_pages_obj = get_pages('sort_column=post_parent,menu_order');
        $options_pages[''] = 'Select a page:';
        foreach ($options_pages_obj as $page) {
            $options_pages[$page->ID] = $page->post_title;
        }

        // If using image radio buttons, define a directory path
        $imagepath = get_stylesheet_directory_uri() . '/images/';

        $options = array();
        /* ---------------------------------------------------------------------------- */
        /* General Setting */
        /* ---------------------------------------------------------------------------- */
        $options[] = array("name" => "General Settings",
            "type" => "heading");
        $options[] = array("name" => "Custom Logo",
            "desc" => "Choose your own logo. Optimal Size: 221px Wide by 84px Height.",
            "id" => "inkthemes_logo",
            "type" => "upload");
        $options[] = array("name" => "Custom Favicon",
            "desc" => "Specify a 16px x 16px image that will represent your website's favicon.",
            "id" => "inkthemes_favicon",
            "type" => "upload");

        $options[] = array("name" => "Body Background Image",
            "desc" => "Select image to change your website background",
            "id" => "inkthemes_bodybg",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Tracking Code",
            "desc" => "Paste your Google Analytics (or other) tracking code here.",
            "id" => "inkthemes_analytics",
            "std" => "",
            "type" => "textarea");
         $options[] = array("name" => "Front Page On/Off",
            "desc" => "Check on for enabling front page or check off for enabling blog page in front page",
            "id" => "re_nm",
            "std" => "on",
            "type" => "radio",
            "options" => $file_rename);
        /* ---------------------------------------------------------------------------- */
        /* Slider Setting */
        /* ---------------------------------------------------------------------------- */
        //Slider Setting
        $options[] = array("name" => "Slider Setting",
            "type" => "heading");
        //First Slider
        $options[] = array("name" => "Slider Image1",
            "desc" => "Choose your image for first slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_slideimage1",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading1",
            "desc" => "Enter your text heading for first slider.",
            "id" => "inkthemes_slider_heading1",
            "std" => "",
            "type" => "textarea");
	 $options[] = array("name" => "First Slider Link URL",
            "desc" => "Enter your link url for first Slider section.",
            "id" => "inkthemes_Slider_link1",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description1",
            "desc" => "Enter your text description for first slider.",
            "id" => "inkthemes_slider_des1",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Second Slider",
            "type" => "saperate",
            "class" => "saperator");
        //Second Slider
        $options[] = array("name" => "Slider Image2",
            "desc" => "Choose your image for second slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_slideimage2",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading2",
            "desc" => "Enter your text heading for second slider.",
            "id" => "inkthemes_slider_heading2",
            "std" => "",
            "type" => "textarea");
		$options[] = array("name" => "Second Slider Link URL",
            "desc" => "Enter your link url for Second Slider section.",
            "id" => "inkthemes_Slider_link2",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description2",
            "desc" => "Enter your text description for second slider.",
            "id" => "inkthemes_slider_des2",
            "std" => "",
            "type" => "textarea");
	    //Third Slider
        $options[] = array("name" => "Third Slider",
            "type" => "saperate",
            "class" => "saperator");    
        $options[] = array("name" => "Slider Image3",
            "desc" => "Choose your image for third slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_slideimage3",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading3",
            "desc" => "Enter your text heading for third slider.",
            "id" => "inkthemes_slider_heading3",
            "std" => "",
            "type" => "textarea");
	    $options[] = array("name" => "Third Slider Link URL",
            "desc" => "Enter your link url for Third Slider section.",
            "id" => "inkthemes_Slider_link3",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description3",
            "desc" => "Enter your text description for third slider.",
            "id" => "inkthemes_slider_des3",
            "std" => "",
            "type" => "textarea");
		   //Fourth Slider
        $options[] = array("name" => "Fourth Slider",
            "type" => "saperate",
            "class" => "saperator");     
        $options[] = array("name" => "Slider Image4",
            "desc" => "Choose your image for fourth slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_image4",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading4",
            "desc" => "Enter your text heading for fourth slider.",
            "id" => "inkthemes_slider_heading4",
            "std" => "",
            "type" => "textarea");
		$options[] = array("name" => "Fourth Slider Link URL",
            "desc" => "Enter your link url for Fourth Slider section.",
            "id" => "inkthemes_Slider_link4",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description4",
            "desc" => "Enter your text description for fourth slider.",
            "id" => "inkthemes_slider_des4",
            "std" => "",
            "type" => "textarea");
	    //Fifth Slider
        $options[] = array("name" => "Fifth Slider",
            "type" => "saperate",
            "class" => "saperator");    
        $options[] = array("name" => "Slider Image5",
            "desc" => "Choose your image for sixth slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_image5",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading5",
            "desc" => "Enter your text heading for fifth slider.",
            "id" => "inkthemes_slider_heading5",
            "std" => "",
            "type" => "textarea");
		$options[] = array("name" => "Fifth Slider Link URL",
            "desc" => "Enter your link url for Fifth Slider section.",
            "id" => "inkthemes_Slider_link5",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description5",
            "desc" => "Enter your text description for fifth slider.",
            "id" => "inkthemes_slider_des5",
            "std" => "",
            "type" => "textarea");
		     //Sixth Slider
        $options[] = array("name" => "Sixth Slider",
            "type" => "saperate",
            "class" => "saperator");   
        $options[] = array("name" => "Slider Image6",
            "desc" => "Choose your image for sixth slider. Optimal size is 950px wide and 460px height.",
            "id" => "inkthemes_image6",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Slider Heading6",
            "desc" => "Enter your text heading for sixth slider.",
            "id" => "inkthemes_slider_heading6",
            "std" => "",
            "type" => "textarea");
		$options[] = array("name" => "Six Slider Link URL",
            "desc" => "Enter your link url for Six Slider section.",
            "id" => "inkthemes_Slider_link6",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Slider Description6",
            "desc" => "Enter your text description for sixth slider.",
            "id" => "inkthemes_slider_des6",
            "std" => "",
            "type" => "textarea");
        /* ---------------------------------------------------------------------------- */
        /* Homepage Feature Area */
        /* ---------------------------------------------------------------------------- */
        $options[] = array("name" => "Homepage Settings",
            "type" => "heading");
        //Homepage Main Heading 
        $options[] = array("name" => "Homepage Main Heading",
            "desc" => "Enter your text heading for homepage main heading",
            "id" => "inkthemes_main_head",
            "std" => "",
            "type" => "textarea");
        //Feature Section
         $options[] = array("name" => "Feature Area",
            "type" => "saperate",
            "class" => "saperator");
        //First Feature Image
        $options[] = array("name" => "First Feature Image",
            "desc" => "Choose your image for first feature section. Optimal size is 202px x 134px.",
            "id" => "inkthemes_feature_img1",
            "std" => "",
            "type" => "upload");
        //Second Feature Image
        $options[] = array("name" => "Second Feature Image",
            "desc" => "Choose your image for second feature section. Optimal size is 202px x 134px.",
            "id" => "inkthemes_feature_img2",
            "std" => "",
            "type" => "upload");
        //Third Feature Image
        $options[] = array("name" => "Third Feature Image",
            "desc" => "Choose your image for third feature section. Optimal size is 202px x 134px.",
            "id" => "inkthemes_feature_img3",
            "std" => "",
            "type" => "upload");
        //Fourth Feature Image
        $options[] = array("name" => "Fourth Feature Image",
            "desc" => "Choose your image for fourth feature section. Optimal size is 202px x 134px.",
            "id" => "inkthemes_feature_img4",
            "std" => "",
            "type" => "upload");
        $options[] = array("name" => "Feature Descriptions",
            "type" => "saperate",
            "class" => "saperator");
        //First Feature Section
        $options[] = array("name" => "First Feature Heading",
            "desc" => "Enter your text heading for first feature section.",
            "id" => "inkthemes_f_head1",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "First Feature Description",
            "desc" => "Enter your text description for first feature section.",
            "id" => "inkthemes_f_des1",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "First Feature Link URL",
            "desc" => "Enter your link url for first feature section.",
            "id" => "inkthemes_link1",
            "std" => "",
            "type" => "text");
        //Second Feature Section
            $options[] = array("name" => "Second Feature Heading",
            "desc" => "Enter your text heading for second feature section.",
            "id" => "inkthemes_f_head2",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Second Feature Description",
            "desc" => "Enter your text description for second feature section.",
            "id" => "inkthemes_f_des2",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Second Feature Link URL",
            "desc" => "Enter your link url for second feature section.",
            "id" => "inkthemes_link2",
            "std" => "",
            "type" => "text");
        //Thrid Feature Section
            $options[] = array("name" => "Third Feature Heading",
            "desc" => "Enter your text heading for third feature section.",
            "id" => "inkthemes_f_head3",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Third Feature Description",
            "desc" => "Enter your text description for third feature section.",
            "id" => "inkthemes_f_des3",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Third Feature Link URL",
            "desc" => "Enter your link url for third feature section.",
            "id" => "inkthemes_link3",
            "std" => "",
            "type" => "text");
        //Fourth Feature Section
          $options[] = array("name" => "Fourth Feature Heading",
            "desc" => "Enter your text heading for fourth feature section.",
            "id" => "inkthemes_f_head4",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Fourth Feature Description",
            "desc" => "Enter your text description for fourth feature section.",
            "id" => "inkthemes_f_des4",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Fourth Feature Link URL",
            "desc" => "Enter your link url for fourth feature section.",
            "id" => "inkthemes_link4",
            "std" => "",
            "type" => "text");
        //Homepage two cols
        $options[] = array("name" => "Homepage Two Cols",
            "type" => "saperate",
            "class" => "saperator");
        //Left Column heading
        $options[] = array("name" => "Left Column Heading",
            "desc" => "Enter your text heading for left column heading.",
            "id" => "inkthemes_left_head",
            "std" => "",
            "type" => "textarea");
        //Right Column heading
         $options[] = array("name" => "Right Column Heading",
            "desc" => "Enter your text heading for right column heading.",
            "id" => "inkthemes_right_head",
            "std" => "",
            "type" => "textarea");
         //Right Column description
         $options[] = array("name" => "Right Column Description",
            "desc" => "Enter your text description for right section. You can put your html code in this section",
            "id" => "inkthemes_right_des",
            "std" => "",
            "type" => "textarea");
         //Contact Area
         $options[] = array("name" => "Contact Area",
            "type" => "saperate",
            "class" => "saperator");
          $options[] = array("name" => "Contact Number",
            "desc" => "Enter your contact number.",
            "id" => "inkthemes_contact_no",
            "std" => "",
            "type" => "text");
          $options[] = array("name" => "Email Address",
            "desc" => "Enter your email address.",
            "id" => "inkthemes_email_add",
            "std" => "",
            "type" => "text");
          $options[] = array("name" => "Date",
            "desc" => "Enter your date.",
            "id" => "inkthemes_date",
            "std" => "",
            "type" => "text");
        /* ---------------------------------------------------------------------------- */
        /* Social Logos */
        /* ---------------------------------------------------------------------------- */
        $options[] = array("name" => "Social Logos",
            "type" => "heading");        
        $options[] = array("name" => "Facebook URL",
            "desc" => "Enter your Facebook URL if you have one",
            "id" => "inkthemes_facebook",
            "std" => "",
            "type" => "text");
         $options[] = array("name" => "Twitter URL",
            "desc" => "Enter your Twitter URL if you have one",
            "id" => "inkthemes_twitter",
            "std" => "",
            "type" => "text");
         $options[] = array("name" => "RSS Feed URL",
            "desc" => "Enter your RSS Feed URL if you have one",
            "id" => "inkthemes_rss",
            "std" => "",
            "type" => "text");
        $options[] = array("name" => "Youtube URL",
            "desc" => "Enter your Youtube URL if you have one",
            "id" => "inkthemes_Youtube",
            "std" => "",
            "type" => "text");       
        $options[] = array("name" => "Yahoo URL",
            "desc" => "Enter your Yahoo URL if you have one",
            "id" => "inkthemes_yahoo",
            "std" => "",
            "type" => "text");
        /* ---------------------------------------------------------------------------- */
        /* Styling Setting */
        /* ---------------------------------------------------------------------------- */
        $options[] = array("name" => "Styling Options",
            "type" => "heading");
        $options[] = array("name" => "Theme Stylesheet",
            "desc" => "Select your themes alternative color scheme.",
            "id" => "inkthemes_altstylesheet",
            "std" => "black",
            "type" => "select",
            "options" => $alt_stylesheets);
        $options[] = array("name" => "Custom CSS",
            "desc" => "Quickly add some CSS to your theme by adding it to this block.",
            "id" => "inkthemes_customcss",
            "std" => "",
            "type" => "textarea");
        /* ---------------------------------------------------------------------------- */
        /* Seo Options */
        /* ---------------------------------------------------------------------------- */
        $options[] = array("name" => "SEO Options",
            "type" => "heading");
        $options[] = array("name" => "Meta Keywords (comma separated)",
            "desc" => "Meta keywords provide search engines with additional information about topics that appear on your site. This only applies to your home page. Keyword Limit Maximum 8",
            "id" => "inkthemes_keyword",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Meta Description",
            "desc" => "You should use meta descriptions to provide search engines with additional information about topics that appear on your site. This only applies to your home page.Optimal Length for Search Engines, Roughly 155 Characters",
            "id" => "inkthemes_description",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Meta Author Name",
            "desc" => "You should write the full name of the author here. This only applies to your home page.",
            "id" => "inkthemes_author",
            "std" => "",
            "type" => "textarea");
        $options[] = array("name" => "Footer Settings",
            "type" => "heading");
        $options[] = array("name" => "Footer Text",
            "desc" => "Enter text you want to be displayed on Footer",
            "id" => "inkthemes_footertext",
            "std" => "",
            "type" => "text");
        inkthemes_update_option('of_template', $options);
        inkthemes_update_option('of_themename', $themename);
        inkthemes_update_option('of_shortname', $shortname);
    }

}
?>
