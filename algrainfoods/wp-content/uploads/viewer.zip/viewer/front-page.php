<?php
/**
 * The template for displaying front page pages.
 *
 */
?>
<?php get_header(); ?>
<div class="slider-wrapper">
    <div id="container">
        <div id="example">
            <div id="slides">
                <div class="slides_container">
                    <!--Start Slider 1-->                    
                    <div class="slide">                         
                        <?php if (inkthemes_get_option('inkthemes_slideimage1') != '') { ?>                        
                            <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link1'); ?>" >
                                <img src="<?php echo inkthemes_get_option('inkthemes_slideimage1'); ?>"  alt="Slide 1"/>
                            </a>
                        <?php } else { ?>
                            <a href="#" >
                                <img src="<?php echo get_template_directory_uri(); ?>/images/slideimg.jpg"  alt="Slide 1"/>
                            </a>
                        <?php } ?>                       
                        <div class="caption">                            
                            <?php if (inkthemes_get_option('inkthemes_slider_heading1') != '') { ?>                             
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link1'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading1')); ?></h2></a>
                            <?php } else { ?>
                                <a href="#"><h2>Theme Heading</h2></a>
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des1') != '') { ?>                              
                                <p> <?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des1')); ?></p>
                            <?php } else { ?>
                                <p>Lorem ipsum dolor sit amet, are to seg an elit. Duis nec purus a quis puar a tortor,</p>
                            <?php } ?>                            
                        </div>
                    </div>                     
                    <!--End Slider 1-->
                    <!--Start Slider 2-->
                    <?php if (inkthemes_get_option('inkthemes_slideimage2') != '') { ?>
                    <div class="slide"> 
                        <?php if (inkthemes_get_option('inkthemes_slideimage2') != '') { ?>
                            <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link2'); ?>"  >
                                <img src="<?php echo inkthemes_get_option('inkthemes_slideimage2'); ?>"  alt="Slide 2" />
                            </a> 
                        <?php } ?>                        
                        <div class="caption">
                            <?php if (inkthemes_get_option('inkthemes_slider_heading2') != '') { ?>
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link2'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading2')); ?></h2></a>                            
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des2') != '') { ?>                           
                                <p> <?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des2')); ?></p>
                            <?php } ?>

                        </div>
                    </div>
                    <?php } ?>
                    <!--End Slider 2-->
                    <!--Start Slider 3-->
                    <?php if (inkthemes_get_option('inkthemes_slideimage3') != '') { ?>
                    <div class="slide"> 
                        <?php if (inkthemes_get_option('inkthemes_slideimage3') != '') { ?>                                
                            <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link3'); ?>"  >
                                <img src="<?php echo inkthemes_get_option('inkthemes_slideimage3'); ?>" alt="Slide 3">
                            </a>
                        <?php } ?>

                        <div class="caption conference">
                            <?php if (inkthemes_get_option('inkthemes_slider_heading3') != '') { ?>                            
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link3'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading3')); ?></h2></a>
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des3') != '') { ?>                            
                                <p><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des3')); ?></p>
                            <?php } ?>                            
                        </div>
                    </div>
                    <?php } ?>
                    <!--End Slider 3-->
                    <!--Start Slider 4-->
                    <?php if (inkthemes_get_option('inkthemes_image4') != '') { ?>
                    <div class="slide"> 
                        <?php if (inkthemes_get_option('inkthemes_image4') != '') { ?>                                
                            <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link4'); ?>"  >
                                <img src="<?php echo inkthemes_get_option('inkthemes_image4'); ?>" alt="Slide 4">
                            </a>
                        <?php } ?>                        
                        <div class="caption conference">
                            <?php if (inkthemes_get_option('inkthemes_slider_heading4') != '') { ?>                            
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link4'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading4')); ?></h2></a>
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des4') != '') { ?>                            
                                <p><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des4')); ?></p>
                            <?php } ?>                            
                        </div>
                    </div>
                    <?php } ?>
                    <!--End Slider 4-->
                    <!--Start Slider 5-->
                    <?php if (inkthemes_get_option('inkthemes_image5') != '') { ?>
                    <div class="slide"> 
                        <?php if (inkthemes_get_option('inkthemes_image5') != '') { ?>                               
                            <a href=" <?php echo inkthemes_get_option('inkthemes_Slider_link5'); ?>"  >
                                <img src="<?php echo inkthemes_get_option('inkthemes_image5'); ?>" alt="Slide 5">
                            </a>
                        <?php } ?>

                        <div class="caption conference">
                            <?php if (inkthemes_get_option('inkthemes_slider_heading5') != '') { ?>                            
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link5'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading5')); ?></h2></a>
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des5') != '') { ?>                            
                                <p><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des5')); ?></p>
                            <?php } ?>                            
                        </div>
                    </div>
                    <?php } ?>
                    <!--End Slider 5-->
                    <!--Start Slider 6-->
                    <?php if (inkthemes_get_option('inkthemes_image6') != '') { ?>
                    <div class="slide">
                        <?php if (inkthemes_get_option('inkthemes_image6') != '') { ?>                                
                            <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link6'); ?>"  >
                                <img src="<?php echo inkthemes_get_option('inkthemes_image6'); ?>" alt="Slide 6">
                            </a>
                        <?php } ?>                        
                        <div class="caption conference">
                            <?php if (inkthemes_get_option('inkthemes_slider_heading6') != '') { ?>                            
                                <a href="<?php echo inkthemes_get_option('inkthemes_Slider_link6'); ?>"><h2><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_heading6')); ?></h2></a>
                            <?php } ?>                            
                            <?php if (inkthemes_get_option('inkthemes_slider_des6') != '') { ?>                            
                                <p><?php echo stripslashes(inkthemes_get_option('inkthemes_slider_des6')); ?></p>
                            <?php } ?>                            
                        </div>
                    </div>
                    <?php } ?>
                    <!--End Slider 6-->
                </div>
            </div>
            <img src="<?php echo get_template_directory_uri(); ?>/images/top-frame.png" alt="Example Frame" id="frame">
        </div>
    </div>
</div>
<div class="clear"></div>
<div class="full-content">
    <div class="feature-content">
        <?php if (inkthemes_get_option('inkthemes_main_head') != '') { ?>
        <h1><?php echo stripslashes(inkthemes_get_option('inkthemes_main_head')); ?></h1>
        <?php } else { ?>        
        <h1><?php _e('Recent Projects','andrina'); ?></h1>
        <?php } ?>        
        <div class="feature-item">
            <?php if (inkthemes_get_option('inkthemes_feature_img1') != '') { ?>
            <a href="<?php echo inkthemes_get_option('inkthemes_link1'); ?>"><img src="<?php echo inkthemes_get_option('inkthemes_feature_img1'); ?>"/></a>
            <?php } else { ?>
            <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img1.jpg"/></a>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_head1') != '') { ?>
            <h4><?php echo stripslashes(inkthemes_get_option('inkthemes_f_head1')); ?></h4>
            <?php } else { ?>            
            <h4><?php _e('Theme Heading pretty.','andrina'); ?></h4>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_des1') != '') { ?>
            <p><?php echo stripslashes(inkthemes_get_option('inkthemes_f_des1')); ?></p>
            <?php } else { ?>
            <p><?php _e('Lorem ipsum dolor sit amet, are to seg an elit. Duis nec purus a quis puar a tortor, quis puar a tortor.','andrina'); ?></p>
            <?php } ?>            
        </div>
        <div class="feature-item">
            <?php if (inkthemes_get_option('inkthemes_feature_img2') != '') { ?>
            <a href="<?php echo inkthemes_get_option('inkthemes_link2'); ?>"><img src="<?php echo inkthemes_get_option('inkthemes_feature_img2'); ?>"/></a>
            <?php } else { ?>
            <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img2.jpg"/></a>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_head2') != '') { ?>
            <h4><?php echo stripslashes(inkthemes_get_option('inkthemes_f_head2')); ?></h4>
            <?php } else { ?>
            <h4><?php _e('Theme Heading pretty.','andrina'); ?></h4>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_des2') != '') { ?>
            <p><?php echo stripslashes(inkthemes_get_option('inkthemes_f_des2')); ?></p>
            <?php } else { ?>
            <p><?php _e('Lorem ipsum dolor sit amet, are to seg an elit. Duis nec purus a quis puar a tortor, quis puar a tortor.','andrina'); ?></p>
            <?php } ?>            
        </div>
        <div class="feature-item">
            <?php if (inkthemes_get_option('inkthemes_feature_img3') != '') { ?>
            <a href="<?php echo inkthemes_get_option('inkthemes_link3'); ?>"><img src="<?php echo inkthemes_get_option('inkthemes_feature_img3'); ?>"/></a>
            <?php } else { ?>
            <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img3.jpg"/></a>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_head3') != '') { ?>
            <h4><?php echo stripslashes(inkthemes_get_option('inkthemes_f_head3')); ?></h4>
            <?php } else { ?>
            <h4><?php _e('Theme Heading pretty.','andrina'); ?></h4>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_des3') != '') { ?>
            <p><?php echo stripslashes(inkthemes_get_option('inkthemes_f_des3')); ?></p>
            <?php } else { ?>
            <p><?php _e('Lorem ipsum dolor sit amet, are to seg an elit. Duis nec purus a quis puar a tortor, quis puar a tortor.','andrina'); ?></p>
            <?php } ?>            
        </div>
        <div class="feature-item">
            <?php if (inkthemes_get_option('inkthemes_feature_img4') != '') { ?>
            <a href="<?php echo inkthemes_get_option('inkthemes_link4'); ?>"><img src="<?php echo inkthemes_get_option('inkthemes_feature_img4'); ?>"/></a>
            <?php } else { ?>
            <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img4.jpg"/></a>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_head4') != '') { ?>
            <h4><?php echo stripslashes(inkthemes_get_option('inkthemes_f_head4')); ?></h4>
            <?php } else { ?>
            <h4><?php _e('Theme Heading pretty.','andrina'); ?></h4>
            <?php } ?>            
            <?php if (inkthemes_get_option('inkthemes_f_des4') != '') { ?>
            <p><?php echo stripslashes(inkthemes_get_option('inkthemes_f_des4')); ?></p>
            <?php } else { ?>
            <p><?php _e('Lorem ipsum dolor sit amet, are to seg an elit. Duis nec purus a quis puar a tortor, quis puar a tortor.','andrina'); ?></p>
            <?php } ?>            
        </div>
    </div>
    <div class="clear"></div>
    <div class="bottom-feature">
        <div class="bottom-feature-left">
            <?php if (inkthemes_get_option('inkthemes_left_head') != '') { ?>
            <h1><?php echo stripslashes(inkthemes_get_option('inkthemes_left_head')); ?></h1>
            <?php } else { ?>
            <h1><?php _e('From The Blog','andrina'); ?></h1>
            <?php } ?> 
            <?php query_posts( 'posts_per_page=2' ); ?>
            <?php if (have_posts()) :  while ( have_posts() ) : the_post(); ?>
            <div class="bottom-feature-left-inner-wrapper">
                <a href="<?php the_permalink() ?>"><?php inkthemes_get_image(185, 165); ?> </a>
                <div class="bottom-feature-left-inner">
                    <h3><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
                   <?php echo inkthemes_custom_trim_excerpt(40); ?>
                    <a href="<?php the_permalink() ?>" class="index-read"></a> 
                </div>
            </div>
           <?php endwhile; endif; ?>
           <?php wp_reset_query(); ?>
        </div>
        <div class="bottom-feature-right">
            <?php if (inkthemes_get_option('inkthemes_right_head') != '') { ?>
            <h1><?php echo stripslashes(inkthemes_get_option('inkthemes_right_head')); ?></h1>
            <?php } else { ?>
            <h1><?php _e('Recent Works','andrina'); ?></h1>
            <?php } ?>            
            <div class="bottom-feature-right-wrapper">
                <?php if (inkthemes_get_option('inkthemes_right_des') != '') { ?>
                <?php echo stripslashes(inkthemes_get_option('inkthemes_right_des')); ?>
            <?php } else { ?>
                <img src="<?php echo get_template_directory_uri(); ?>/images/vids.png" />
                <p>Even if it ain't pretty  it's fricken  cool, best hing since sliced thebread and instant is a sliced thebread and instant is a sliced thebread and instant is a cool,st thing since sliced thebread and instant is a  ven if it ain't pretty it's icken  sliced .</p>
            <?php } ?>                
            </div>
        </div>
    </div>
</div>
<div class="clear"></div>
<div class="index-info">
    <div class="grid_6 alpha">
        <div class="index-info-one">            
            <?php if (inkthemes_get_option('inkthemes_contact_no') != '') { ?>
            <span><?php echo stripslashes(inkthemes_get_option('inkthemes_contact_no')); ?></span>
            <?php } else { ?>
            <span><?php _e('9981-121212','andrina'); ?></span>
            <?php } ?>                       
        </div>
    </div>
    <div class="grid_7">
        <div class="index-info-two">
             <?php if (inkthemes_get_option('inkthemes_email_add') != '') { ?>
            <span><?php echo stripslashes(inkthemes_get_option('inkthemes_email_add')); ?></span>
            <?php } else { ?>
            <span><?php _e('mail@bodegazine.com','andrina'); ?></span>
            <?php } ?>               
        </div>
    </div>
    <div class="grid_11 omega">
        <div class="index-info-three">
             <?php if (inkthemes_get_option('inkthemes_date') != '') { ?>
            <span><?php echo stripslashes(inkthemes_get_option('inkthemes_date')); ?></span> 
            <?php } else { ?>
            <span><?php _e('Monday To Saturday 8 Am To 8 Pm','andrina'); ?></span> 
            <?php } ?>            
        </div>
    </div>
</div>


</div>
<!--End Index-->
<?php get_footer(); ?>