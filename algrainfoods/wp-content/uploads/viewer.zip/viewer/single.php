<?php
/**
 * The Template for displaying all single posts.
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>
<?php get_header(); ?>
	<div class="clear"></div>
        <div class="page-content single_page">
          <div class="grid_16 alpha">
            <div class="content-bar">
   <!-- Start the Loop. -->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<!--post Start-->
              <div class="post">
                <h1 class="post_title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
                 <ul class="post_meta">
                    <li class="post_date"><?php echo get_the_time('m, d, Y') ?></li>
                    <li class="post_category"><span>/&nbsp;&nbsp;Category</span>&nbsp;<?php the_category(', '); ?></li>
                    <li class="posted_by"><span>/&nbsp;&nbsp;</span>Posted By&nbsp;<?php the_author_posts_link(); ?></li>
                    <li class="postc_comment"><span>/&nbsp;&nbsp;</span>&nbsp;<?php comments_popup_link('No Comments.', '1 Comment.', '% Comments.'); ?></li>
                  </ul>
                <div class="post_content">  <?php the_content(); ?>
				  <div class="clear"></div>
                    <?php if (has_tag()) { ?>
                        <div class="tag">
                            <?php the_tags('Post Tagged with ', ', ', ''); ?>
                        </div>
                    <?php } ?>
                 </div>
              </div>
              <!--post End-->
			  <?php endwhile;
else: ?>
   <div class="post">
        <p>
            <?php _e('Sorry, no posts matched your criteria.', 'andrina'); ?>
        </p>
    </div>
<?php endif; ?>
<!--End Loop-->			  
             <!--Start Comment box-->
     <?php comments_template(); ?>
            <!--End Comment box-->
            </div>
          </div>
          <div class="grid_8 omega">
       <!--Start Sidebar-->
        <?php get_sidebar(); ?>
        <!--End Sidebar-->
          </div>
        </div>
      </div>
	  <?php get_footer(); ?> 