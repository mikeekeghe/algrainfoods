
<?php get_header(); ?>

<?php get_template_part(''.$zn_lays = of_get_option('layout_images').''); ?>


<?php get_footer(); ?>