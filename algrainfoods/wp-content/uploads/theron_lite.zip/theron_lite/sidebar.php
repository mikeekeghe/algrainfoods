<div id="sidebar">
    <div class="widgets"><ul>          
            <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Right Sidebar') ) : ?> 
            <?php endif; ?></ul>
            </div>
    </div>