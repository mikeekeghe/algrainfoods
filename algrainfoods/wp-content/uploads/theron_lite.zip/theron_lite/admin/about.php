
            <div id="tab_about">
                    
                  <div class="tab_option" id="sub_theme">
                  <h4><label>About the theme</label></h4>
            <p>Theron is a wordpress 3 theme with awesome skins, fonts, slider, layouts &amp; easy to use theme option panel.</p>
            <ul style="margin-top:10px; margin-left:10px; list-style-type:circle;">
            <li style="float:none; background:none; border:none; padding:0; margin:0; display:list-item; line-height:22px;"><a style=" color:#2bb975;" href="http://www.towfiqi.com/theron-lite-free-wordpress-theme.html" target="_blank">Theron Lite(Free)</a></li>
            <li style="float:none; background:none; border:none; padding:0; margin:0; display:list-item; line-height:22px;"><a style=" color:#2bb975;" href="http://www.towfiqi.com/theron-pro-wordpress-theme.html" target="_blank">Theron  Pro(Commercial)</a></li>
            </ul>
            
                        <p>Both of the themes are licensed under <a style=" color:#2bb975;" href="http://www.gnu.org/licenses/old-licenses/gpl-2.0.html">GNU General Public License v2 </a></p>
                	</div>
                
                <div class="tab_option" id="sub_dev">        
                 <h4><label>About Developer </label></h4>
                 This Theme is designed and devloped by <a target="_blank" style=" color:#2bb975;" href="http://www.towfiqi.com/">Towfiq I.</a><br />
            
            <p>For update and support refer to any of these pages:
            <ul>
            <li><a style=" color:#2bb975;" target="_blank" href="http://www.facebook.com/pages/Towfiq-I/180981878579536">Facebook</a></li>
            <li><a style=" color:#2bb975;" target="_blank" href="http://www.twitter.com/towfiqi">Twitter</a></li>
            <li><a style=" color:#2bb975;" target="_blank" href="https://plus.google.com/114788083723678273482/">Google plus</a></li>
            <li><a style=" color:#2bb975;" target="_blank" href="http://www.towfiqi.com/">Website</a></li>
            </ul>
            </p>
            
			</div>
            
            
                
                </div>
                
